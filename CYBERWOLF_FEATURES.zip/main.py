from cyber_wolf_hunter import wolfhunter

data =wolfhunter("https://cyberwolf.pro" , thread=100)
data.scan()